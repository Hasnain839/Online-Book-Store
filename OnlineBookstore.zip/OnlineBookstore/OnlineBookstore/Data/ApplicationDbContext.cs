﻿using Microsoft.EntityFrameworkCore;
using OnlineBookstore.Models;
using System.Collections.Generic;

namespace OnlineBookstore.Data
{
    public class ApplicationDbContext:DbContext 
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }
        public DbSet<Book> Books { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Book>(entity =>
            {
                // Explicitly define the column type and precision for the Price property
                entity.Property(e => e.Price)
                    .HasColumnType("decimal(18,2)");  // precision: 18, scale: 2
            });
        }
    }
}
